    function addTask() {
      const input = document.getElementById('taskInput');
      const taskText = input.value.trim();
      if (taskText === '') return;

      const li = document.createElement('li');

      const checkmark = document.createElement('span');
      checkmark.innerHTML = '✔️';
      checkmark.className = 'checkmark';
      checkmark.onclick = () => li.classList.toggle('completed');

      const text = document.createElement('span');
      text.className = 'task-text';
      text.textContent = taskText;
      text.textContent = "🙂 " + taskText; // ✅ Added emoji here

      const removeBtn = document.createElement('button');
      removeBtn.className = 'remove-btn';
      removeBtn.textContent = 'Remove';
      removeBtn.onclick = () => li.remove();

      li.appendChild(checkmark);
      li.appendChild(text);
      li.appendChild(removeBtn);

      document.getElementById('taskList').appendChild(li);

      input.value = '';
    }


